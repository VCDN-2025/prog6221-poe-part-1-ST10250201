﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;
using System.Media;
using System.Threading;
using System.IO;

namespace CyberAwareBot
{
    using System.Media;
    using System.Net.Http.Headers;

    class Program
    {
        private static readonly object Greetings;

        public static MediaTypeHeaderValue GreetingWAV { get; private set; }

        static void Main(string[] args)
        {
           var player = new MediaTypeHeaderValue("\"C:\\Users\\Mishen Naidoo\\OneDrive\\Desktop\\WhatsApp Audio 2025-04-23 at 13.32.27_e8afd38e.waptt.wav\"");
            player = (GreetingWAV);
        }
    }

    class Chatbot
    {
        static void Main(string[] args)
        {
            DisplayASCIIArt(args);
        }

        private static void DisplayASCIIArt(string[] args)
        {
            throw new NotImplementedException();
        }

        public string BotName { get; set; } = "Cybersecurity Awareness Bot";
        public Dictionary<string, string> Responses { get; set; }

        public Chatbot()
        {
            Responses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "How are you doing?", "I'm good, thank you for asking. I'm here to assist you on staying safe online." },
                { "what's your purpose?", "My purpose is to educate you on cybersecurity threats and how to avoid them." },
                { "what may i ask you about?", "You may ask me about password safety, phishing, safe browsing, and more." },
                { "password safety", "Use strong, unique passwords for your accounts. Consider using a password manager." },
                { "phishing", "Be cautious of emails asking for personal information. Always verify the sender's address." },
                { "safe browsing", "Avoid visiting unknown links and use secure (HTTPS) websites whenever possible." }
            };
        }


        public void Respond(string input)
        {
            // strip punctuation and normalize
            var key = input.Trim().TrimEnd('?', '!', '.').ToLower();
            if (Responses.TryGetValue(key, out var reply))
            {
                TypeWrite(reply + "\n");
            }
            else
            {
                TypeWrite("I didn't quite understand that. Could you rephrase?\n");
            }
        }

        // simple typing effect
        public void TypeWrite(string message, int delay = 30)
        {
            foreach (var ch in message)
            {
                Console.Write(ch);
                Thread.Sleep(delay);
            }
        }
    }

    public class Master
    {
        static void Main(string[] args)
        {
            Console.Title = "Cybersecurity Awareness Bot";
            Console.WindowWidth = 100;

            // 1. Voice Greeting
            try
            {

                var player = new MediaTypeHeaderValue("\"C:\\Users\\Mishen Naidoo\\OneDrive\\Desktop\\WhatsApp Audio 2025-04-23 at 13.32.27_e8afd38e.waptt.wav\"");


            }
            catch
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("⚠  (Could not play voice greeting - make sure greeting.wav is in your output folder)\n");
                Console.ResetColor();
            }

            // Initialize bot and show ASCII art header
            var bot = new Chatbot();
           

            // 3. Ask for user's name with input validation
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Please enter your name: ");
            Console.ResetColor();

            string userName;
            while (true)
            {
                userName = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(userName)) break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Name cannot be empty. Please enter your name: ");
                Console.ResetColor();
            }

           

            // 4 & 5. Chat loop with basic response system & input validation
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("> ");
                Console.ResetColor();

                var input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please enter a question or type 'exit' to quit.\n");
                    Console.ResetColor();
                    continue;
                }

                // exit condition
                if (input.Equals("exit", StringComparison.OrdinalIgnoreCase) ||
                    input.Equals("quit", StringComparison.OrdinalIgnoreCase))
                {
                    bot.TypeWrite("\nGoodbye! Stay safe online!\n");
                    break;
                }

                bot.Respond(input);
            }
        }
    }
}
